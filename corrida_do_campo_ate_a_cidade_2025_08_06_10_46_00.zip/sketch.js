let xJogador = [0, 0, 0, 0];
let yJogador = [75, 150, 225, 300];
let Jogador = ["🚕", "🛻", "🚗", "🚓"];
let teclas = ["w", "a", "s", "d"];
let quantidade = Jogador.length;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  ativaJogo();
  desenhaJogadores();
  desenhaLinhaDeChegada();
  verificaVencedor();

  // instruções na tela
  fill("rgb(238,238,250)");
  textSize(20);
  text("Para começar o jogo basta clicar na tela,", 10, 320);
  text("para os personagens se moverem use", 5, 340);
  text("as teclas w, a, s, d", 15, 360);
}

function ativaJogo() {
  if (focused === true) {
    background("#07F0FA");
  } else {
    background("#363030");
  }
}

function desenhaJogadores() {
  textSize(40);
  for (let i = 0; i < quantidade; i++) {
    text(Jogador[i], xJogador[i], yJogador[i]);
  }
}

function desenhaLinhaDeChegada() {
  fill("white");
  rect(350, 0, 10, 400);
  fill("black");
  for (let yAtual = 0; yAtual < 400; yAtual += 20) {
    rect(350, yAtual, 10, 10);
  }
}

function verificaVencedor() {
  for (let i = 0; i < quantidade; i++) {
    if (xJogador[i] > 350) {
      textSize(24);
      fill("yellow");
      text(Jogador[i] + " chegou à cidade!", 50, 200);
      noLoop(); // para o jogo
    }
  }
}

function keyReleased() {
  for (let i = 0; i < quantidade; i++) {
    if (key.toLowerCase() === teclas[i]) {
      xJogador[i] += random(20);
    }
  }
}